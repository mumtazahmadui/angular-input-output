import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { HomeComponent } from './home/home.component';
import { ComponentOneComponent } from './home/component-one/component-one.component';
import { ComponentTwoComponent } from './home/component-two/component-two.component';
import { ComponentThreeComponent } from './home/component-three/component-three.component';
import { ComponentFourComponent } from './home/component-four/component-four.component';
import { ComponentFiveComponent } from './home/component-five/component-five.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    HomeComponent,
    ComponentOneComponent,
    ComponentTwoComponent,
    ComponentThreeComponent,
    ComponentFourComponent,
    ComponentFiveComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
